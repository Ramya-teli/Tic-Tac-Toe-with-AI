# Here’s an interesting twist on the classic Tic-Tac-Toe game with AI. In this version, the game is played on a larger 5x5 grid, and the first player to connect 4 marks in a row (horizontally, vertically, or diagonally) wins.

# The AI doesn’t just make random moves but uses the Minimax algorithm to make intelligent decisions to either win or block the player from winning.